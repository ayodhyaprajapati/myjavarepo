# Angular8-SpringBoot-CRUD-Tutorial
Develop a single page application(SPA) using Angular 8 as a front-end and Spring boot restful API as a backend.

https://www.javaguides.net/2019/06/spring-boot-angular-7-crud-example-tutorial.html

# YouTube Video

https://youtu.be/lYMKywB46go
